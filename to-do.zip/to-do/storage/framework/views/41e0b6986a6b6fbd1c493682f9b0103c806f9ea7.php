<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                        <?php if(session('warning')): ?>
                            <div class="alert alert-warning" role="alert">
                                <?php echo e(session('warning')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('delete')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('delete')); ?>

                            </div>
                        <?php endif; ?>
                    <p><a href="<?php echo e(route('create.item')); ?>" class="btn btn-primary" >Add To Do Item</a></p>
                    <div class="table-responsive">
                        <table class="table ">
                        <tr>
                            <th>#</th>
                            <th>Subject</th>
                            <th>Description</th>
                            <th>Priority</th>
                            <th>Start</th>
                            <th>Finish</th>
                            <th colspan="2">Actions</th>

                            <?php $count = 0;?>
                        </tr>

                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $count ++;?>
                            <tr>
                                <td><?php echo e($count); ?></td>
                            <td><?php echo e($item->subject); ?></td>
                            <td><?php echo e($item->description); ?></td>
                                <td><?php echo e($item['priority'] === 1 ? 'Critical' : ''); ?>

                                    <?php echo e($item['priority'] === 2 ? 'High' : ''); ?>

                                    <?php echo e($item['priority'] === 3 ? 'Medium' : ''); ?>

                                    <?php echo e($item['priority'] === 4 ? 'Low' : ''); ?>

                                    <?php echo e($item['priority'] === 5 ? 'Very Low' : ''); ?></td>
                            <td><?php echo e($item->start_at); ?></td>
                            <td><?php echo e($item->finish_at); ?></td>
                                <td><a class="btn btn-warning" href="<?php echo e(route('todo.edit',['item'=>$item->id])); ?>">Edit</a>  </td>
                                    <td>
                                    <a class="btn btn-danger" href="<?php echo e(route('todo.delete',['item'=>$item->id])); ?>"> Delete</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\to-do\resources\views/home.blade.php ENDPATH**/ ?>